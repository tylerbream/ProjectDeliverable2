package basketballshooter;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.paint.Color;
import javafx.application.Application;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Bounds;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.BorderPane;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Viewer extends Application {

    final Label sliderValue = new Label();
    
    @Override
    public void start(Stage primaryStage) {

        Slider slider = new Slider();
        slider.setMin(0);
        slider.setMax(100);
        slider.setValue(50);
        slider.setShowTickLabels(true);
        slider.setShowTickMarks(true);
        slider.setMajorTickUnit(50);
        slider.setMinorTickCount(5);
        slider.setBlockIncrement(10);

        final Label sliderCaption = new Label("Power Meter");
        

        BorderPane grid = new BorderPane();
        grid.setPadding(new Insets(15, 20, 10, 10));

        slider.setPadding(new Insets(5, 5, 5, 5));
        grid.setBottom(slider);
        BorderPane.setAlignment(slider, Pos.TOP_RIGHT);
        slider.setMaxWidth(400);

        sliderCaption.setPadding(new Insets(5, 5, 5, 5));
        sliderValue.setPadding(new Insets(5, 5, 5, 5));

        grid.setCenter(sliderCaption);
        grid.setRight(sliderValue);

        BorderPane.setAlignment(sliderValue, Pos.BOTTOM_RIGHT);
        BorderPane.setAlignment(sliderCaption, Pos.BOTTOM_RIGHT);

        BorderPane.setMargin(slider, new Insets(10, 10, 10, 10));

        Scene scene = new Scene(grid, 550, 250);

        Button shoot = new Button("Shoot");
        shoot.relocate(100, 0);

        Circle ball = new Circle(15, Color.ORANGE);
        ball.relocate(50, 250);

        grid.getChildren().add(ball);
        grid.setLeft(shoot);

        slider.valueProperty().addListener((ObservableValue<? extends Number> ov, Number old_val, Number new_val) -> {
            sliderValue.setText(String.format("%.2f", new_val));
            double power = (double) new_val;
            
            Timeline timeline = new Timeline(new KeyFrame(Duration.millis(Double.parseDouble(sliderValue.getText())), new EventHandler<ActionEvent>() {
                
                double dx = 7; //Step on x or velocity
                double dy = 3; //Step on y
                
                @Override
                public void handle(ActionEvent t) {
                    //move the ball
                    ball.setLayoutX(ball.getLayoutX() + dx);
                    ball.setLayoutY(ball.getLayoutY() + dy);
                    
                    Bounds bounds = grid.getBoundsInLocal();
                    
                    //If the ball reaches the left or right border make the step negative
                    if (ball.getLayoutX() <= (bounds.getMinX() + ball.getRadius())
                            || ball.getLayoutX() >= (bounds.getMaxX() - ball.getRadius())) {
                        
                        dx = -dx;
                        
                    }
                    
                    //If the ball reaches the bottom or top border make the step negative
                    if ((ball.getLayoutY() >= (bounds.getMaxY() - ball.getRadius()))
                            || (ball.getLayoutY() <= (bounds.getMinY() + ball.getRadius()))) {
                        
                        dy = -dy;
                        
                    }
                    
                }
            }));
            EventHandler<ActionEvent> event = (ActionEvent e) -> {
                timeline.setCycleCount(Timeline.INDEFINITE);
                timeline.play();
            };
            shoot.setOnAction(event);
        });

        primaryStage.setTitle("Basketball Shooter");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
