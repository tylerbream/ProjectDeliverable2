package basketballshooter;

import java.io.FileNotFoundException;
import java.util.Random;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.paint.Color;
import javafx.application.Application;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Bounds;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Viewer extends Application {

    final Label sliderValue = new Label();

    @Override
    public void start(Stage primaryStage) throws FileNotFoundException {

        Slider slider = new Slider();
        slider.setMin(0);
        slider.setMax(100);
        slider.setValue(50);
        slider.setShowTickLabels(true);
        slider.setShowTickMarks(true);
        slider.setMajorTickUnit(50);
        slider.setMinorTickCount(5);
        slider.setBlockIncrement(10);

        final Label sliderCaption = new Label("Power Meter");
        final Label scoreLabel = new Label("Score");

        BorderPane grid = new BorderPane();
        grid.setPadding(new Insets(15, 20, 10, 10));
        grid.setStyle("-fx-background-color: white");

        slider.setPadding(new Insets(5, 5, 5, 5));
        grid.setBottom(slider);
        BorderPane.setAlignment(slider, Pos.TOP_RIGHT);
        slider.setMaxWidth(400);

        sliderCaption.setPadding(new Insets(5, 5, 5, 5));
        scoreLabel.setPadding(new Insets(5, 5, 5, 5));
        sliderValue.setPadding(new Insets(5, 5, 5, 5));

        grid.setCenter(sliderCaption);
        grid.setRight(sliderValue);

        BorderPane.setAlignment(sliderValue, Pos.BOTTOM_RIGHT);
        BorderPane.setAlignment(sliderCaption, Pos.BOTTOM_RIGHT);
        BorderPane.setAlignment(scoreLabel, Pos.TOP_RIGHT);

        BorderPane.setMargin(slider, new Insets(10, 10, 10, 10));

        Scene scene = new Scene(grid, 550, 250);

        Button shoot = new Button("Shoot");
        shoot.relocate(100, 0);
        Button reset = new Button("Reset");
        reset.relocate(200, 0);

        Circle ball = new Circle(25, Color.ORANGE);
        Random random = new Random();
        int randomInt = random.nextInt(350) + 1;
        ball.relocate(randomInt, 500);

        Image image = new Image(getClass().getResourceAsStream("/hoop.jpg"));
        ImageView imageView = new ImageView(image);
        imageView.setX(1600);
        imageView.setY(200);

        //setting the fit height and width of the image view 
        imageView.setFitHeight(300);
        imageView.setFitWidth(345);

        //Setting the preserve ratio of the image view 
        imageView.setPreserveRatio(true);
        grid.getChildren().add(imageView);

        grid.getChildren().add(ball);
        grid.setLeft(shoot);
        grid.setTop(reset);
        grid.setCenter(scoreLabel);

        slider.valueProperty().addListener((ObservableValue<? extends Number> ov, Number old_val, Number new_val) -> {
            sliderValue.setText(String.format("%.2f", new_val));
            double power = (double) new_val;

            Timeline timeline = new Timeline(new KeyFrame(Duration.millis(15), new EventHandler<ActionEvent>() {

                double dx = Double.parseDouble(sliderValue.getText()); //Step on x or velocity
                double dy = -75; //Step on y
                int score = 0;

                @Override
                public void handle(ActionEvent t) {
                    //move the ball
                    dy += 3;
                    ball.setLayoutX(ball.getLayoutX() + dx);
                    ball.setLayoutY(ball.getLayoutY() + dy);

                    Bounds bounds = grid.getBoundsInLocal();

                    //If the ball reaches the left or right border make the step negative
                    if ((ball.getLayoutX() >= (bounds.getMaxX() - ball.getRadius()))
                            || (ball.getLayoutX() <= (bounds.getMinX() + ball.getRadius()))) {

                        dx = -dx;
                    }

                    //If the ball reaches the bottom or top border make the step negative
                    if ((ball.getLayoutY() >= (bounds.getMaxY() - ball.getRadius()))) {
                        dy = -dy + 3;
                    }

                    if (ball.getLayoutX() >= 1650 && ball.getLayoutX() <= 1790
                            && ball.getLayoutY() >= 280 && ball.getLayoutY() <= 330) {
                        score += 1;
                        scoreLabel.setText("Score: " + score);
                    }

                }
            }));
            EventHandler<ActionEvent> event = (ActionEvent e) -> {
                timeline.setCycleCount(Timeline.INDEFINITE);
                timeline.play();
            };
            EventHandler<ActionEvent> event2 = (ActionEvent e) -> {
                timeline.stop();
                int randomInt2 = random.nextInt(350) + 1;
                ball.relocate(randomInt2, 500);
            };
            shoot.setOnAction(event);
            reset.setOnAction(event2);
        });

        primaryStage.setTitle("Basketball Shooter");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
