package basketballshooter;

public class BasketballShooter {

    public static void main(String[] args) {
        Controller cntl = new Controller();
    }

    
    /*
    We added gravity, score, a basketball hoop.
    We tried implementing the MVC framework with our JavaFX application but we would get a lot of errors when our controller would be instantiated in the view class.
    We also fixed a problem where the shot power was not being used correctly
    */
    
    
}
