package basketballshooter;

public class BasketballShooter {

    public static void main(String[] args) {
        Controller cntl = new Controller();
    }

    
    /*
    We added the ball and the power of the shot based on the user's input from the slider, and made the ball bounce.
    We tried adding gravity functionality, but that was unsuccessful, we will save that for next deliverable as well as the hoop
    Control class creates instance of viewer and model
    We have contol, model, and viewer class
    */
    
    
}
