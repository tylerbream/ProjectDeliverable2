package basketballshooter;

public class Controller {

    Viewer shotView;
    Model model;

    public Controller() {
        model = new Model(this);
    }

    public Double getShotPower() {
        return model.calculateShotPower();
    }

    public Double updateShotPower() {
        return Double.parseDouble(shotView.sliderValue.getText());
    }
}
