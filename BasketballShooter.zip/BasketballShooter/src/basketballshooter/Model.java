package basketballshooter;

public class Model {

    private final Controller cntl;

    public Model(Controller cntl) {
        this.cntl = cntl;
    }

    public Double calculateShotPower() {
        return cntl.updateShotPower();
    }

}
