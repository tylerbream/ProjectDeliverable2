package basketballshooter;

public class Shot {

    private final double distance;
    private final double pointWorth;

    public Shot(double distance, double pointWorth) {
        this.distance = distance;
        this.pointWorth = pointWorth;
    }

}
